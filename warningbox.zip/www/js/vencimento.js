function salvar() {
    alert('Vencimento inserido com sucesso!');
}