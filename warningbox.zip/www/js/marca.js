function salvar() {
    alert('Marca inserida com sucesso!');
}